## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment  = "#>",
  message  = FALSE,
  warning  = FALSE
)

## ----load---------------------------------------------------------------------
library(HydroBasin)

## ----eval = FALSE-------------------------------------------------------------
# packageVersion("HydroBasin")

## ----basin, eval = FALSE------------------------------------------------------
# # Path to example extent
# aoi <- system.file("extdata/aoi_example.shp", package = "HydroBasin")
# 
# # Delineate (interactive pour‑point picker will pop up)
# basin <- delineate_basin(
#   aoi      = aoi,
#   out_dir  = file.path(tempdir(), "hb_demo"),
#   quiet    = TRUE
# )
# 
# # Inspect
# basin

## ----runoff, eval = FALSE-----------------------------------------------------
# runoff <- calculate_runoff(
#   basin       = basin,           # sf object from step 1
#   start_date  = "2020-01-01",
#   end_date    = "2024-03-31",
#   return_plot = TRUE,
#   quiet       = TRUE
# )
# 
# # First six rows
# head(runoff$data)
# 
# # Plot (returns a ggplot object)
# runoff$plot

## ----write, eval = FALSE------------------------------------------------------
# readr::write_csv(runoff$data, "monthly_basin_runoff_volume.csv")

## ----session------------------------------------------------------------------
sessionInfo()

