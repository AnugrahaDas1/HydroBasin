# HydroBasin 0.9.0

* First public release on CRAN.
* New `delineate_basin()` function for automated watershed delineation.
* New `calculate_runoff()` function for TerraClim-based water-balance.
* Added vignette “HydroBasin: End-to-End Workflow”.
